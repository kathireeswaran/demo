package com.cg.hms.dao;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.Patient;

public interface HMSDao {

	int fixAppointment(Patient patient) throws HMSException;




}
