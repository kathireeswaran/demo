package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.Patient;
import com.cg.hms.presentation.HMSMain;
import com.cg.hms.utility.JdbcUtility;

public class HMSDaoImpl implements HMSDao {
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultset=null;

	static Logger logger = Logger.getLogger(HMSMain.class);

	/**
	 * method :addPatientDetails; 
	 * argument :it's taking model object as an argument
	 * return type :this method returns the generated id to the user
	 * author:Capgemini 
	 * date :14-jan-2019
	 */

	@Override
	public int fixAppointment(Patient patient) throws HMSException {
		logger.info("in fixAppointment method");
		connection = JdbcUtility.getConnection();
		int generatedid = 0;
		logger.info("connection is successful");
		try {
			statement = connection.prepareStatement(QueryMapper.insertPatientDetails);
			logger.info("statement is created");
			statement.setString(1, patient.getName());
			statement.setString(2, patient.getGender());
			statement.setLong(3, patient.getPhoneNumber());
			statement.setString(4, patient.getProblem());
			statement.executeQuery();
			logger.info("query executed");
			statement = connection.prepareStatement(QueryMapper.getPatientid);
			resultset = statement.executeQuery();
			logger.info("resultset created");
			resultset.next();
			generatedid = resultset.getInt(1);
			logger.info("generatedid is"+generatedid);
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HMSException("problem occurs while creating statement object");
		}
		finally {
			logger.info("in finallt block");
			try {
				statement.close();
			} catch (SQLException e) {
					
				throw new HMSException("statement not closed");
			}
			try {
				
				connection.close();
				logger.info("connection closed");
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new HMSException("connection not closed");
			}
		}
		return generatedid;

	}
}
