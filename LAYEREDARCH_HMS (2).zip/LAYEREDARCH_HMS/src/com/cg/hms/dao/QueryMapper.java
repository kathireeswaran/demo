package com.cg.hms.dao;

public interface QueryMapper {
public static final String insertPatientDetails="insert into hms_table values(patient_seq.nextval,?,?,?,sysdate,?)";
public static final String getPatientid="select patient_seq.currval from dual";
}
