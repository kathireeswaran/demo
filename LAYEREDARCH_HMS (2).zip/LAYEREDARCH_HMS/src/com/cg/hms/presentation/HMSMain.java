package com.cg.hms.presentation;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.Patient;
import com.cg.hms.sevice.HMSService;
import com.cg.hms.sevice.HMSServiceImpl;

public class HMSMain {

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		Scanner scanner = null;
		HMSService hmsService;
		int choice=0;
		do {
		System.err.println("******HOSPITAL MANAGEMENT SYSTEM*********");
		System.out.println("1.Book Appointement");
		System.out.println("2.get Appointement details");
		System.out.println("3.view all booked appointment");
		System.out.println("4.exit");
		System.out.println();
		scanner = new Scanner(System.in);
		try {
			System.out.println("Enter ur choices:");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:

					scanner.nextLine();
				System.out.println("Enter the Patient Name:  ");
					String name=scanner.nextLine();
					System.out.println("Enter the Gender :");
					String gender=scanner.nextLine();
					System.out.println("Enter the phoneNumber :");
					Long no=scanner.nextLong();
					scanner.nextLine();
					System.out.println("Enter the PROBLEM :");
					String problem=scanner.nextLine();
					Patient patient=new Patient();
					patient.setName(name);
					patient.setGender(gender);
					patient.setPhoneNumber(no);
					patient.setProblem(problem);
					hmsService=new HMSServiceImpl();
				try {
					boolean validationflag=hmsService.validation(patient);
					if(validationflag)
					{
						int id=hmsService.fixAppointment(patient);
						System.out.println("ur id is :"+id);
					}
				} catch (HMSException e) {
					System.err.println(e.getMessage());
					e.printStackTrace();
				}
				break;
			case 2:

				break;
			case 3:

				break;
			case 4:

				break;

			default:
				System.out.println("invalid selection..pls try again");
				break;
			}
		}
		catch (InputMismatchException e) {
			System.err.println("enter only digits");
		}
		}while(!(choice>0&&choice<5));
		scanner.close();
	}
}
