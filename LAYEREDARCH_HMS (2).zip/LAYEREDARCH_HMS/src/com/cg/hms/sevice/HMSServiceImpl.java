package com.cg.hms.sevice;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.hms.dao.HMSDao;
import com.cg.hms.dao.HMSDaoImpl;
import com.cg.hms.exception.HMSException;
import com.cg.hms.model.Patient;

public class HMSServiceImpl implements HMSService {
	List<String> list = new ArrayList<>();
	boolean validateflag = false;
	HMSDao hmsdao = new HMSDaoImpl();

	@Override
	public boolean validation(Patient patient) throws HMSException {
		if (!checkname(patient.getName())) {
			list.add("name must be captial");
		}
		if (!checkGender(patient.getGender())) {
			list.add("add either male r female");
		}
		if (!checknumber(patient.getPhoneNumber())) {
			list.add("enter valid phoneno:");
		}
		if (!list.isEmpty()) {
			throw new HMSException(list + " ");
		} else {
			validateflag = true;
		}
		return validateflag;
	}

	public boolean checkname(String name) {
		String nameRegEx = "[A-Z]{1}[A-Za-z\\s]{4,19}$";
		return Pattern.matches(nameRegEx, name);
	}

	public boolean checkGender(String gender) {
		String genderRegEx = "MALE|male|female|FEMALE";
		return Pattern.matches(genderRegEx, gender);
	}
	public boolean checknumber(long phonenumber) {
		String phoneRex = "[6|7|8|9]{1}[0-9]{9}";
		return Pattern.matches(phoneRex, Long.toString(phonenumber));
	}

	@Override
	public int fixAppointment(Patient patient) throws HMSException {
		// TODO Auto-generated method stub
		return hmsdao.fixAppointment(patient);
	}
}
