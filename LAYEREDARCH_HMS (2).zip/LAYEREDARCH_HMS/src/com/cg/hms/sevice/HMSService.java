package com.cg.hms.sevice;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.Patient;

public interface HMSService {

	boolean validation(Patient patient) throws HMSException;

	int fixAppointment(Patient patient) throws HMSException;

}
