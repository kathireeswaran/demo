package com.cg.ems.main;

import java.util.Scanner;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employeemodel;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class UI {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter name");
		String name = scanner.nextLine();
		System.out.println("enter salary");
		double salary = scanner.nextDouble();
		scanner.nextLine();
		System.out.println("enter address");
		String address = scanner.nextLine();
		Employeemodel employeemodel = new Employeemodel();
		employeemodel.setName(name);
		employeemodel.setSalary(salary);
		employeemodel.setAddress(address);
		EmployeeService service = new EmployeeServiceImpl();
		try {
			int result = service.insertEmployee(employeemodel);
			System.out.println(result + "employee inserted");
		} catch (EMSException e) {
			System.err.println(e.getMessage());
		}

	}

}
