package com.cg.ems.main;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.cg.ems.exception.EMSException;
import com.cg.ems.utility.JdbcUtility;

public class callable {
/*public static void main(String[] args)  {
	CallableStatement Statement=null;
	Connection  connection=null;
   try {
	connection=JdbcUtility.getConnection();

	   String query="{call jee_proc(?,?,?)}";
	   Statement=connection.prepareCall(query);
	   Statement.setString(1, "kathireeswaran");
	   Statement.setDouble(2, 33333);
	   Statement.setString(3, "hyderbad");
	 int  result=Statement.executeUpdate();
	 System.out.println("inserted");
} catch (EMSException e) {
	System.err.println(e.getMessage());
} 
   catch (SQLException e) {
	System.err.println(e.getMessage());
}
}*/
	public static void main(String[] args) {
		
	}
}
