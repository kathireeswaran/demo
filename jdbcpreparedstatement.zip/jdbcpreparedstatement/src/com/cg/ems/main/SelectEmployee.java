package com.cg.ems.main;

import java.util.List;
import java.util.Scanner;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employeemodel;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class SelectEmployee {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter id");
		int id = scanner.nextInt();
		int id2 =scanner.nextInt();
		EmployeeService employeeService= new EmployeeServiceImpl();
		try {
			List<Employeemodel> list=employeeService.getemployeedetails(id ,id2);
			if (list.size() > 0) {
				System.out.println( "NAME" + "    " + "salary" +"   "+"address");
				for (Employeemodel emp1 : list) {
					System.out.println(emp1.getId()+" "+emp1.getName() + "    " + emp1.getSalary()+"   "+emp1.getAddress());
				}
			} else {
				System.out.println("no data");
			}
		} catch (EMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
