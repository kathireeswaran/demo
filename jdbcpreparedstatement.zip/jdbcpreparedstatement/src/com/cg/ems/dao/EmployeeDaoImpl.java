package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employeemodel;
import com.cg.ems.utility.JdbcUtility;


public class EmployeeDaoImpl implements EmployeeDAO {
	PreparedStatement statement = null;
	Connection connection = null;

	@Override
	public int insertEmployee(Employeemodel employeemodel) throws EMSException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			statement = connection.prepareStatement(QueryMapper.insertQuery);
			statement.setString(1, employeemodel.getName());
			statement.setDouble(2, employeemodel.getSalary());
			statement.setString(3, employeemodel.getAddress());
			result = statement.executeUpdate();
		} catch (SQLException e) {
			throw new EMSException("STATEMENT NOT CREATED");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new EMSException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new EMSException("connection is not closed");
			}
		}
		return result;
	}

	@Override
	public int updateemployee(Employeemodel employeemodel) throws EMSException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			statement = connection.prepareStatement(QueryMapper.updateQuery);
			statement.setDouble(1, employeemodel.getSalary());
			statement.setString(2, employeemodel.getAddress());
			statement.setInt(3, employeemodel.getId());
			result = statement.executeUpdate();
		} catch (SQLException e) {
			throw new EMSException("connection not found");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new EMSException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new EMSException("connection is not closed");
			}
		}
		return result;

	}

	@Override
	public List<Employeemodel> getemployeedetails(int id,int id2) throws EMSException {
		List<Employeemodel> list2 = new ArrayList<>();
		ResultSet resultSet = null;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.selectQuery);
			statement.setInt(1, id);
			statement.setInt(2, id2);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				 id=resultSet.getInt("id");
				String name = resultSet.getString("name");
				Double salary = resultSet.getDouble("salary");
				String address = resultSet.getString("address");
				Employeemodel employeemodel = new Employeemodel();
				employeemodel.setId(id);
				employeemodel.setName(name);
				employeemodel.setSalary(salary);
				employeemodel.setAddress(address);
				list2.add(employeemodel);
			}

		} catch (SQLException e) {
		
			e.printStackTrace();
		} finally {
			try {
				statement.close();
			} catch (Exception e2) {
				throw new EMSException("statement is not closed");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new EMSException("connection is not closed");
			}

		}

		return list2;
	}

}
