package com.cg.ems.dao;

import java.util.Scanner;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employeemodel;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class Updatemain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter id");
		int id = scanner.nextInt();
		System.out.println("enter salary");
		double salary = scanner.nextDouble();
		scanner.nextLine();
		System.out.println("enter address");
		String address = scanner.nextLine();
		Employeemodel employeemodel = new Employeemodel();
		employeemodel.setSalary(salary);
		employeemodel.setAddress(address);
		employeemodel.setId(id);
		scanner.close();
		EmployeeService employeeService = new EmployeeServiceImpl();
		int result = 0;
		try {
			result = employeeService.updateemployee(employeemodel);
			System.out.println(result + "updated");
		} catch (EMSException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
		}

	}

}
