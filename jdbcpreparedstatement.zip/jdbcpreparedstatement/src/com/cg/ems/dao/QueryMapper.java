package com.cg.ems.dao;

public interface QueryMapper {
	public final static String insertQuery = "insert into jee_abridged_master values(jee_abridged_sequence.nextval,?,?,?)";

	public final static String updateQuery = "update jee_abridged_master set salary=?,address=? where id=?";
	
	public final static String selectQuery="select * from jee_abridged_master where id >? and id<?";

}
