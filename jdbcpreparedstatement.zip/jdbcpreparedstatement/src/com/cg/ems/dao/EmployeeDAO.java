package com.cg.ems.dao;

import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employeemodel;

public interface EmployeeDAO {

	int insertEmployee(Employeemodel employeemodel) throws EMSException;

	int updateemployee(Employeemodel employeemodel) throws EMSException;

	

	List<Employeemodel> getemployeedetails(int id,int id2) throws EMSException;

}
