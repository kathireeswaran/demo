package com.cg.ems.service;

import java.util.List;

import com.cg.ems.dao.EmployeeDAO;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employeemodel;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO employeeDao = new EmployeeDaoImpl();

	@Override
	public int insertEmployee(Employeemodel employeemodel) throws EMSException {
		// TODO Auto-generated method stub
		return employeeDao.insertEmployee(employeemodel);
	}

	@Override
	public int updateemployee(Employeemodel employeemodel) throws EMSException {
		// TODO Auto-generated method stub
		return employeeDao.updateemployee(employeemodel);
	}


	@Override
	public List<Employeemodel> getemployeedetails(int id ,int id2) throws EMSException {
		// TODO Auto-generated method stub
		return employeeDao.getemployeedetails(id,id2);
	}
}
