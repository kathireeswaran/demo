package com.cg.ems.service;

import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employeemodel;

public interface EmployeeService {

	int insertEmployee(Employeemodel employeemodel) throws EMSException;

	int updateemployee(Employeemodel employeemodel) throws EMSException;

	List<Employeemodel> getemployeedetails(int id,int id2) throws EMSException;

	boolean validateFields(int id, int id2) throws EMSException;



}
