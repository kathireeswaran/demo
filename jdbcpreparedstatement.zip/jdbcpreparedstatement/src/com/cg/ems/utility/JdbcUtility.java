package com.cg.ems.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.ems.exception.EMSException;

public class JdbcUtility {
	private static Connection connection = null;
	static String url = "jdbc:oracle:thin:@localhost:1521:XE";
	static String user = "system";
	static String password = "corp123";

	public static Connection getConnection() throws EMSException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			throw new EMSException("class not found");
		}
		try {
			connection=DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			throw new EMSException("connection not found");
		}
		return connection;
	}

}
