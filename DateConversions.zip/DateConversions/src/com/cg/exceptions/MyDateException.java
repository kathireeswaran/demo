package com.cg.exceptions;

public class MyDateException extends Exception {

	public MyDateException(String message) {
		super(message);
	}
}
