package com.cg.dates.main;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

import com.cg.dates.service.DateService;
import com.cg.dates.service.DateServiceImpl;
import com.cg.model.User;

public class DateConversion {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		DateTimeFormatter formatter = null;
		LocalDate date = null;
		boolean flag = false;

		System.out.println("name");
		String name = scanner.nextLine();

		do {
			scanner = new Scanner(System.in);
			System.out.println("date of birth (dd-MM-yyyy)");
			String dob = scanner.nextLine();

			formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			try {
				date = LocalDate.parse(dob, formatter);
				flag = true;
				
			} catch (DateTimeParseException e) {
				flag = false;
				System.err.println("date is not in the given format, give the date in dd-MM-yyyy format ");
			}
		} while (!flag);

		User user = new User();
		user.setName(name);
		user.setDate(date);

		DateService service = new DateServiceImpl();
		int res = service.insertUser(user);
		System.out.println(res + "inserted..");
	}

}
