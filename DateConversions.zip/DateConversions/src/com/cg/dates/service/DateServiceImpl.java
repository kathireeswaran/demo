package com.cg.dates.service;

import com.cg.dates.dao.DateDao;
import com.cg.dates.dao.DateDaoImpl;
import com.cg.model.User;

public class DateServiceImpl implements DateService {

	DateDao dao = new DateDaoImpl();

	@Override
	public int insertUser(User user) {
		return dao.adduser(user);
	}

}
