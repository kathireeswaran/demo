package com.cg.dates.service;

import com.cg.model.User;

public interface DateService {

	int insertUser(User user);

}
