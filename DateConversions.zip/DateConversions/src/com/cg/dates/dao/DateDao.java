package com.cg.dates.dao;

import com.cg.model.User;

public interface DateDao {

	int adduser(User user);

}
