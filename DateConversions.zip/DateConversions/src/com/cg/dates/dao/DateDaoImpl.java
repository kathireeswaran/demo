package com.cg.dates.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.model.User;

public class DateDaoImpl implements DateDao {

	@Override
	public int adduser(User user) {

		Connection connection = null;
		PreparedStatement statement = null;

		int res = 0;
		Date date = Date.valueOf(user.getDate());

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "123");
			statement = connection.prepareStatement("insert into test_date_table values(?,?)");
			statement.setString(1, user.getName());
			statement.setDate(2, date);
			res = statement.executeUpdate();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}

}
